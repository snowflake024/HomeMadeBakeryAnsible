#!/bin/sh
#####################################################################
# find_expiring_users.sh                                            #
#####################################################################
#
##  set -x

WERT=""
WERT_1=""
WERT_2=""
echo "" > /usr/lib/check_mk_agent/find_expiring_users_OUT.txt
/usr/lib/check_mk_agent/bin/find_expiring_users.sh 2>/dev/null >> /usr/lib/check_mk_agent/find_expiring_users_OUT.txt
FILE="/usr/lib/check_mk_agent/find_expiring_users_OUT.txt"
CAT=cat
unset WERT
unset WERT_1
unset WERT_2
WERT="notset"
WERT_1="notset"
WERT_2="notset"
UNIX95=yes ${CAT} ${FILE} |grep -iE cmkmon | grep -iE 'already expired' 1>/dev/null 2>&1 && UNIX95=yes typeset -i WERT_1=`UNIX95=yes ${CAT} ${FILE} |grep -iE cmkmon | grep -iE 'already expired' | awk '{ print $(NF-2) }'`
UNIX95=yes ${CAT} ${FILE} |grep -iE cmkmon | grep -iE 'will expire in' 1>/dev/null 2>&1 && UNIX95=yes typeset -i WERT_2=`UNIX95=yes ${CAT} ${FILE} |grep -iE cmkmon | grep -iE 'will expire in' | awk '{ print $(NF-1) }'`
# typeset -i WERT="${WERT_1:=${WERT_2}}"
TEXT="`UNIX95=yes ${CAT} ${FILE} |grep -iE cmkmon`"



ECHO=echo
if [ "${WERT_1}" != "notset" ]
then
	## $ECHO "User ist bereits abgelaufen"
	typeset -i WERT="-${WERT_1}"
else
	## $ECHO "User ist noch NICHT abgelaufen"
	typeset -i WERT="${WERT_2}"
fi

if [ $WERT -ge 64 ]
then
	 # echo "0 \"\"APPL_CMK Password Age cmkmon\"\" PW_Age_cmkmon=${WERT};64;32 \"\"${TEXT}\"\""
	 echo "0 \"APPL_CMK_Password_Age_cmkmon\" PW_Age_cmkmon=${WERT};64;32 \"${TEXT}\""
 
 elif [ $WERT -ge 32 ] ; then
	 # echo "0 \"\"APPL_CMK Password Age cmkmon\"\" PW_Age_cmkmon=${WERT};64;32 \"\"${TEXT}\"\""
	 echo "1 \"APPL_CMK_Password_Age_cmkmon\" PW_Age_cmkmon=${WERT};64;32 \"${TEXT}\""
 
else
	 # echo "0 \"\"APPL_CMK Password Age cmkmon\"\" PW_Age_cmkmon=${WERT};64;32 \"\"${TEXT}\"\""
	 echo "2 \"APPL_CMK_Password_Age_cmkmon\" PW_Age_cmkmon=${WERT};64;32 \"${TEXT}\""
 
fi
#


# set -x 
CAT=cat
CFG_FILE="/var/lib/check_mk_agent/find_expiring_users_All_LNX_CFG_file.cfg"
# Check if CFG File is available -> if not simply touch it to be sure that the script is working well
ls -altr ${CFG_FILE} 1>/dev/null 2>&1 && \cp -p ${CFG_FILE} ${CFG_FILE}_backup
ls -altr ${CFG_FILE} 1>/dev/null 2>&1 || touch ${CFG_FILE}
# Variable definitions read out from CFG File
# for LINE in `cat ${CFG_FILE}`
while read LINE
do
        USER="`echo ${LINE} | cut -d\; -f1`"
        ALARM_THRESHOLD_CRIT="`echo ${LINE} | cut -d\; -f2`"
        ALARM_THRESHOLD_MIN="`echo ${LINE} | cut -d\; -f3`"

	# just in case somethiong wents wron define a defaul alert value
	ALERT_VAL=35
	# if no ALARM_THRESHOLD are given by the konfig file set the defaults one
	ALARM_THRESHOLD_MIN="`echo ${ALARM_THRESHOLD_MIN:-32}`"
	ALARM_THRESHOLD_CRIT="`echo ${ALARM_THRESHOLD_CRIT:-16}`"

	unset WERT
	unset WERT_1
	unset WERT_2
	WERT="notset"
	WERT_1="notset"
	WERT_2="notset"
	UNIX95=yes ${CAT} ${FILE} |grep -i ${USER} | grep -iE 'already expired' 1>/dev/null 2>&1 && UNIX95=yes typeset -i WERT_1=`UNIX95=yes ${CAT} ${FILE} |grep -i ${USER} | grep -iE 'already expired' | awk '{ print $(NF-2) }'`
	UNIX95=yes ${CAT} ${FILE} |grep -i ${USER} | grep -iE 'will expire in' 1>/dev/null 2>&1 && UNIX95=yes typeset -i WERT_2=`UNIX95=yes ${CAT} ${FILE} |grep -i ${USER} | grep -iE 'will expire in' | awk '{ print $(NF-1) }'`
	# typeset -i WERT="${WERT_1:=${WERT_2}}"
	TEXT="`UNIX95=yes ${CAT} ${FILE} |grep -i ${USER}`"

ECHO=echo
if [ "${WERT_1}" != "notset" ]
then
	## $ECHO "User ist bereits abgelaufen"
	typeset -i WERT="-${WERT_1}"
else
	## $ECHO "User ist noch NICHT abgelaufen"
	typeset -i WERT="${WERT_2}"
fi
## LARM_THRESHOLD_CRIT}
if [ $WERT -ge ${ALARM_THRESHOLD_MIN} ]
then
	 echo "0 \"APPL_CMK_Password_Age_${USER}\" PW_Age_${USER}=${WERT};${ALARM_THRESHOLD_MIN};${ALARM_THRESHOLD_CRIT} \"${TEXT}\""
 
 elif [ $WERT -ge ${ALARM_THRESHOLD_CRIT} ] ; then
	 echo "1 \"APPL_CMK_Password_Age_${USER}\" PW_Age_${USER}=${WERT};${ALARM_THRESHOLD_MIN};${ALARM_THRESHOLD_CRIT} \"${TEXT}\""
 
else
	 echo "2 \"APPL_CMK_Password_Age_${USER}\" PW_Age_${USER}=${WERT};${ALARM_THRESHOLD_MIN};${ALARM_THRESHOLD_CRIT} \"${TEXT}\""
 
fi
#
done < ${CFG_FILE}







CAT=cat
unset WERT
unset WERT_1
unset WERT_2
WERT="notset"
WERT_1="notset"
WERT_2="notset"
UNIX95=yes ${CAT} ${FILE} |grep -iE root | grep -iE 'already expired' 1>/dev/null 2>&1 && UNIX95=yes typeset -i WERT_1=`UNIX95=yes ${CAT} ${FILE} |grep -iE root | grep -iE 'already expired' | awk '{ print $(NF-2) }'`
UNIX95=yes ${CAT} ${FILE} |grep -iE root | grep -iE 'will expire in' 1>/dev/null 2>&1 && UNIX95=yes typeset -i WERT_2=`UNIX95=yes ${CAT} ${FILE} |grep -iE root | grep -iE 'will expire in' | awk '{ print $(NF-1) }'`
# typeset -i WERT="${WERT_1:=${WERT_2}}"
TEXT="`UNIX95=yes ${CAT} ${FILE} |grep -iE root`"



ECHO=echo
HOST="`hostname`"
if [ "${WERT_1}" != "notset" ]
then
        ## $ECHO "User ist bereits abgelaufen"
        typeset -i WERT="-${WERT_1}"
	MESSAGE_TEXT="The User root on the Server ${HOST} already expired ${WERT_1} days ago - Owner: uxos@a1.at"
else
        ## $ECHO "User ist noch NICHT abgelaufen"
        typeset -i WERT="${WERT_2}"
	MESSAGE_TEXT="The User root on the Server ${HOST} will expire in ${WERT_2} days - Owner: uxos@a1.at"
fi
## echo "P \"APPL_CMK_Password_Age_root\" PW_Age_root=${WERT};64;32 \"${TEXT}\""

## WERT=29
###
if [ $WERT -ge 64 ]
then
         # echo "0 \"\"APPL_CMK Password Age root\"\" PW_Age_root=${WERT};64;32 \"\"${TEXT}\"\""
         # UNIX95=yes echo "0 \"APPL_CMK_Password_Age_root\" PW_Age_root=${WERT};64;32 \"`UNIX95=yes grep 'root' ${FILE}`\""
         # UNIX95=yes echo "0 \"APPL_CMK_Password_Age_root\" PW_Age_root=${WERT};64;32 \"`UNIX95=yes grep 'root' ${FILE}`\""
           UNIX95=yes echo "0 \"APPL_CMK_Password_Age_root\" PW_Age_root=${WERT};64;32 \"${MESSAGE_TEXT}\""

 elif [ $WERT -ge 32 ] ; then
         # echo "0 \"\"APPL_CMK Password Age root\"\" PW_Age_root=${WERT};64;32 \"\"${TEXT}\"\""
         # echo "1 \"APPL_CMK_Password_Age_root\" PW_Age_root=${WERT};64;32 \"${TEXT}\""
         # UNIX95=yes echo "1 \"APPL_CMK_Password_Age_root\" PW_Age_root=${WERT};64;32 \"`UNIX95=yes grep 'root' ${FILE}`\""
         # UNIX95=yes echo "1 \"APPL_CMK_Password_Age_root\" PW_Age_root=${WERT};64;32 \"`UNIX95=yes grep 'root' ${FILE}`\""
           UNIX95=yes echo "1 \"APPL_CMK_Password_Age_root\" PW_Age_root=${WERT};64;32 \"${MESSAGE_TEXT}\""

else
         # echo "0 \"\"APPL_CMK Password Age root\"\" PW_Age_root=${WERT};64;32 \"\"${TEXT}\"\""
         # echo "2 \"APPL_CMK_Password_Age_root\" PW_Age_root=${WERT};64;32 \"${TEXT}\""
         # UNIX95=yes echo "2 \"APPL_CMK_Password_Age_root\" PW_Age_root=${WERT};64;32 \"`UNIX95=yes grep 'root' ${FILE}`\""
         # UNIX95=yes echo "2 \"APPL_CMK_Password_Age_root\" PW_Age_root=${WERT};64;32 \"`UNIX95=yes ${ECHO} ${TEXT}`\""
           UNIX95=yes echo "2 \"APPL_CMK_Password_Age_root\" PW_Age_root=${WERT};64;32 \"${MESSAGE_TEXT}\""

fi

